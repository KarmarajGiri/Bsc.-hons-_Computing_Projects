BookName = []
AuthorName = []
Quantity = []
Price = []
def lists ():
    f = open ("Stock.txt","r")
    read = f.readlines()
    read = [a.strip("\n") for a in read]
    for i in range(len(read)):
        x = 0
        for j in read[i].split(","):
            #print (j)
            if(x==0):
                BookName.append(j)
                #print(Books)
            elif(x==1):
                AuthorName.append(j)
            elif(x==2):
                Quantity.append(j)
            elif(x==3):
                Price.append(j.strip("$"))
            x=x+1
