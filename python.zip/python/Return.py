import listsplits
import DateTime
def ReturnBook():
    name=input("Enter name of borrower: ")
    a="Borrowed by-"+name+".txt"
    try:
        f=open(a,"r")
        lines=f.readlines()
        lines=[a.strip("$") for a in lines]
        f.close()
    
        f=open(a,"r")
        data=f.read()
        print(data)
    except:
        print("The borrower name is incorrect or not registered.")
        ReturnBook()

    Return="Returned by-"+name+".txt"
    f=open(Return,"w+")
    f.write("\t\t\t\t Library Management System \n\n")
    f.write("\t\t\t Returned By: "+ name+"\n")
    f.write("\t\t\t Date and Time: " + DateTime.getDate()+"\n\n")
    f.write("S.N. \t\t Book Name \t\t Price\n")
    f.close()

    total=0.0
    for i in range(3):
        if listsplits.BookName[i] in data:
            f=open(Return,"a")
            f.write(str(i+1)+" \t\t "+listsplits.BookName[i]+" \t\t"+" $"+listsplits.Price[i]+"\n")
            f.close()
            listsplits.Quantity[i]=int(listsplits.Quantity[i])+1
            total+=int(listsplits.Price[i])
            
    print("The book return date expires in 10 days. Has the book return date already expired?")
    print("Press Y for Yes and N for No")
    choice=input().upper
    if(choice()=="Y"):
        print("By how many days was the book returned late?")
        day=int(input())
        fine=3*day
        f=open(Return,"a")
        f.write("\n\t\t\t\t\tFine: $"+ str(fine)+"\n")
        f.close()
        total=total+fine
    

    print("Final Total: "+ "$"+str(total))
    f=open(Return,"a")
    f.write("\t\t\t\t\tFinal Total: $"+ str(total))
    f.close()
    
        
    f=open("Books.txt","w+")
    for i in range(3):
        f.write(listsplits.BookName[i]+","+listsplits.AuthorName[i]+","+str(listsplits.Quantity[i])+","+"$"+listsplits.Price[i]+"\n")
