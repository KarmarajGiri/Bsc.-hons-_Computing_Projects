def getDate():
    import datetime
    now = datetime.datetime.now()
    #print("Date: ",now().date())
    return str(now.date())

def getTime():
    import datetime
    now = datetime.datetime.now()
    return str(now.time())
#getTime()
