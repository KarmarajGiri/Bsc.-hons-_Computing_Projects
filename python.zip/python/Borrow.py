import DateTime
import listsplits

def BorrowBook():
    Borrowed = False
    while(True):
        FirstName = input("Input the First Name of the Borrower: ")
        if FirstName.isalpha():
            break
        print("Please input alphabet from A-Z to continue")
    while(True):
        LastName=input("Input the Last Name of the Borrower: ")
        if LastName.isalpha():
            break
        print("Please input alphabet from A-Z to continue")

    Borrow = "Borrowed by-"+FirstName+".txt"
    f = open(Borrow,"w+")
    f.write("\t\t Library Management System  \n\n")
    f.write("\t\t Borrowed By: "+ FirstName+" "+LastName+"\n")
    f.write("\t\t Date and Time: " + DateTime.getDate()+"\n\n")
    f.write("S.N. \t\t Bookname \t\t\t Authorname \t\t Price\n" )
    f.close()
    while Borrowed == False:
        print("\nPlease select a option below:\n")
        for i in range(len(listsplits.BookName)):
            print("Input", i, "to borrow book", listsplits.BookName[i])


        try:
            a=int(input())
            try:
                if(int(listsplits.Quantity[a])>0):
                    print("The Book you have selected is available\n")
                    f=open(Borrow,"a")
                    f.write("1. \t\t"+ listsplits.BookName[a]+" \t\t\t  "+listsplits.AuthorName[a]+" \t\t  "+"$"+listsplits.Price[a]+"\n")
                    f.close()
                    listsplits.Quantity[a]=int(listsplits.Quantity[a])-1
                    f=open("Books.txt","w+")
                    for i in range(3):
                        f.write(listsplits.BookName[i]+","+listsplits.AuthorName[i]+","+str(listsplits.Quantity[i])+","+"$"+listsplits.Price[i]+"\n")
                    f.close()



                    #Code for Borrowing multiples books at a time
                    Borrowed2=True
                    count=1

                    while Borrowed2==True:
                        choice=str(input("If you want to borrow another book then press Y for Yes if not then press N for No: \n").upper())
                        if(choice=="Y"):
                            count=count+1              
                            print("\nPlease select an option below:\n")
                            for i in range(len(listsplits.BookName)):
                                print("Input", i, "to borrow book", listsplits.BookName[i])
                            a=int(input())
                            if(int(listsplits.Quantity[a])>0):
                                print("Book is available\n")
                                f=open(Borrow,"a")
                                f.write(str(count)+". \t\t"+ listsplits.BookName[a]+"\t\t\t  "+listsplits.AuthorName[a]+" \t\t  "+"$"+listsplits.Price[a]+"\n")
                                f.close()


                                listsplits.Quantity[a]=int(listsplits.Quantity[a])-1
                                f=open("Books.txt","w+")
                                for i in range(3):
                                    f.write(listsplits.BookName[i]+","+listsplits.AuthorName[i]+","+str(listsplits.Quantity[i])+","+"$"+listsplits.Price[i]+"\n")
                                f.close()
                                Borrowed=False
                               
                                
                            else:
                                Borrowed2=False
                                break
                        elif(choice=="N"):
                            print("\nThank you for borrowing books from us. ")
                            print("")
                            Borrowed2=False
                            Borrowed=True
                        else:
                            print("Please input as suggested")
                            
                    total=0.0
                    total+=float(listsplits.Price[i])
                    total+=float(listsplits.Price[i])
                    f=open(Borrow,"a")
                    f.write("\t\t\t\t\t\t\t\t\tTotal: $"+ str(total))
                    f.close()


                else:
                    print("Book is not available right now. Please visit us after some time.")
                    BorrowBook()
                    Borrowed=False
            except IndexError:
                print("")
                print("Please choose book acording to their number.")
        except ValueError:
            print("")
            print("Please input as suggested.")
                                


























                        
            
