import Return
import DateTime
import Borrow
import listsplits

def start():
    while(True):
        print('''    Welcome to the Library.
- Press 1: To Display books.
- Press 2: To Borrow books.
- Press 3: To Return books.
- Press 4: To Exit .''')
        n = int(input("Enter your choice: "))
        
        try:
            if(n==1):
                file = open("Stock.txt","r")
                lines=file.read()
                print(lines)
                print ()   
            elif(n==2):
               listsplits.lists()
               Borrow.BorrowBook()
            elif(n==3):
                listsplits.lists()
                Return.ReturnBook()
            elif(n==4):
                print("Thank you for using library management system")
                break
            else:
                print("Please enter a valid numbr")
        except ValueError:
            print("Please input as suggested.")
start()
