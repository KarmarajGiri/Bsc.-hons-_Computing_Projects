from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name='home'),
    path("dashboard/", views.dashboard, name='dashboard'),
    path('donator/<str:pk>/', views.donator, name='donator'),
    path('create_donation/', views.create_donation, name='create_donation'),
    path('update_donation/<str:pk>/',
         views.update_donation, name='update_donation'),
    path('delete_donation/<str:pk>/',
         views.delete_donation, name='delete_donation'),

     path('donations/', views.donations, name='donations'),
]
