from django.db import models
from django.contrib.auth.models import User


class Donator(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone = models.CharField(max_length=200, null=True)
    email = models.CharField(max_length=200, null=True)
    address = models.CharField(max_length=200, null=True)
    date_created = models.DateField(auto_now_add=True, null=True)

    def __str__(self) -> str:
        return self.user.username


class Donation(models.Model):
    TYPE = (
        ('Food', 'Food'),
        ('Book', 'Book'),
        ('Cloth', 'Cloth'),
    )

    donator = models.ForeignKey(
        Donator, null=True, on_delete=models.SET_NULL)
    type = models.CharField(max_length=200, choices=TYPE)
    image = models.ImageField(upload_to='donation_images/', blank=True, null=True) # add the image field
    date_created = models.DateField(auto_now_add=True, null=True)


    # def __str__(self) -> str:
    #     if self.donatio
    #     return f"{self.donator.user.username} - {self.type} ({self.date_created})"
