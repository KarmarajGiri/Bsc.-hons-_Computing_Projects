from django.forms import ModelForm
from .models import Donation
from django import forms


from django import forms
from .models import Donation

from django import forms
from .models import Donation


class DonationForm(forms.ModelForm):
    class Meta:
        model = Donation
        fields = ['type', 'image']
        widgets = {
            'type': forms.Select(attrs={'class': 'form-control'}),
            'image': forms.ClearableFileInput(attrs={'multiple': True}),
        }




