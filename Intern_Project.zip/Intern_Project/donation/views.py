from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
from .forms import DonationForm
from django.contrib.auth.decorators import login_required


def index(request):
    return render(request, 'donation/index.html')


def dashboard(request):
    donations = Donation.objects.order_by('date_created')[:5]
    donators = Donator.objects.order_by('date_created')[:5]

    food_donations = Donation.objects.filter(
        type='Food').order_by('date_created')[:5]

    book_donations = Donation.objects.filter(
        type='Book').order_by('date_created')[:5]

    cloth_donations = Donation.objects.filter(
        type='Cloth').order_by('date_created')[:5]

    total_donators = Donator.objects.all().count()
    total_donations = Donation.objects.all().count()

    food = Donation.objects.all().filter(type='Food').count()
    book = Donation.objects.all().filter(type='Book').count()
    cloth = Donation.objects.all().filter(type='Cloth').count()

    context = {
        'donations': donations,
        'donators': donators,
        'total_donators': total_donators,
        'total_donations': total_donations,
        'food_donations': food_donations,
        'book_donations': book_donations,
        'cloth_donations': cloth_donations,
        'food': food,
        'book': book,
        'cloth': cloth,
    }

    return render(request, 'donation/dashboard.html', context)


def donator(request, pk):
    donator = Donator.objects.get(id=pk)
    donations = donator.donation_set.all()
    donation_count = donations.count()

    context = {
        'donator': donator,
        'donations': donations,
        'donation_count': donation_count
    }

    return render(request, 'donation/donator.html', context)


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from .forms import DonationForm


@login_required(login_url='login')
def create_donation(request):
    form = DonationForm()

    if request.method == 'POST':
        form = DonationForm(request.POST, request.FILES)
        if form.is_valid():
            donation = form.save(commit=False)
            donation.donator = request.user.donator
            donation.save()
            return redirect('dashboard')

    context = {
        'form': form
    }

    return render(request, 'donation/donation_form.html', context)






@login_required(login_url='login')
def update_donation(request, pk):
    donation = Donation.objects.get(id=pk)

    form = DonationForm(instance=donation)
    if request.method == 'POST':
        form = DonationForm(request.POST, instance=donation)
        if form.is_valid():
            form.save()
            return redirect('dashboard')

    context = {
        'form': form
    }

    return render(request, 'donation/donation_form.html', context)


@login_required(login_url='login')
def delete_donation(request, pk):
    donation = Donation.objects.get(id=pk)

    if request.method == 'POST':
        donation.delete()
        return redirect('dashboard')

    context = {
        'item': donation
    }

    return render(request, 'partials/delete.html', context)


def donations(request):
    donations = Donation.objects.order_by('date_created')
    context = {
        'donations': donations
    }

    return render(request, 'donation/donations.html', context)
