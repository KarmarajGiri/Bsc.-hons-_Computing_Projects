const date = new Date();

document.getElementById('year').innerHTML = date.getFullYear()

setTimeout(function () {
	$('#message').fadeOut('slow');
}, 3000);
